#!/bin/bash
# usage: ocr.sh <pdf> <outtxt>
f="$1"; o="$2"; t=$(mktemp -d)
pdftoppm -r 200 -gray "$f" "$t/p" >/dev/null 2>&1
: > "$o"
for im in $(ls "$t"/p*.pgm | sort -V); do tesseract "$im" - -l eng --psm 6 2>/dev/null >> "$o"; echo -e "\n=== page break ===" >> "$o"; done
rm -rf "$t"
